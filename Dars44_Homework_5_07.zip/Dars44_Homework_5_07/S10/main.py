def Fill_color_type():
    data = []
    while True:
        color = input("To'xtatish uchun '0' ni bosing, Color: ")
        if color == '0': 
            break
        else: 
            data.append(color.capitalize())
    return data

def Spent_time(data):
    change_pencil = 1
    print_square = 2
    n = len(data)
    all_time = 0
    for i in range(n)[1:]:
        if n == 1:
            break
        elif n > 1:
            if data[i] == data[i-1]:
                all_time += print_square
            else: 
                all_time += (change_pencil + print_square)

    return all_time+2 if n > 0 else all_time
        
Color_data = Fill_color_type()
print(Color_data)
print(f"Output: {Spent_time(Color_data)}")
