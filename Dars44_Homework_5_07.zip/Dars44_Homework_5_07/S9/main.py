def Fill_list():
    num_list = []

    while True:
        num = input("To'xtatish uchun 'c' ni bosing, num = ")
        if num.upper() == 'C': 
            break
        elif not num.isalnum():
            if int(num) < 0:
                num_list.append(int(num))
            else:
                continue
        else: 
            num_list.append(int(num))
    return num_list

def Sort_my_sort(data):
    all_infos = {}
    for i in range(len(data)):
        sum_num = lambda son: sum(int(raqam) for raqam in str(data[i]))
        natija = sum_num(data[i])          
        all_infos[data[i]] = natija

    sorted_values = dict(sorted(all_infos.items(), key = lambda item: item[1]))
    new_list = []
    for key, value in sorted_values.items():
        new_list.append(key)
    return new_list

My_sort = Fill_list()
print(My_sort)
print("Raqamlari yig'indisi bo'yicha sortlanishi: ")
print(Sort_my_sort(My_sort))
    