def fill_list():
    num_list = []

    while True:
        num = input("To'xtatish uchun 'c' ni bosing, num = ")
        if num.upper() == 'C': 
            break
        elif not num.isalnum():
            if int(num) < 0:
                num_list.append(int(num))
            else:
                continue
        else: 
            num_list.append(int(num))
    return num_list

def Check_sample(list):

    for i in range(len(list)-1):
        if list[i] >= 0 and list[i+1] >= 0:
            print(list[i], list[i+1])
        elif list[i] < 0 and list[i+1] < 0:
            print(list[i], list[i+1])


num_list = fill_list()
print(num_list)
Check_sample(num_list)