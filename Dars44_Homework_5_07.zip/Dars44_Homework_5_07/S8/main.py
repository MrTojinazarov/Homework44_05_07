def Fill_Data():
    people_infos = []

    while True:
        person_info = []
        person_info.append(input("Name: "))
        person_info.append(input("Lavozimi: "))
        person_info.append(int(input("Oyligi: ")))
        person_info.append(int(input("Bonus: ")))
        person_info.append(input("Bo'lim (1 or 2 or 3): "))
        people_infos.append(person_info)
        sign = input("Stop(0), Continue(1) : ")
        if sign == '1':
            continue
        else:
            break
    return people_infos

def Check_Data(infos):
    cnt1,cnt2,cnt3 = 0,0,0
    for i in range(len(infos)):
        if infos[i][3] > 0 and infos[i][4]=='1':
            cnt1 += 1
        elif infos[i][3] > 0 and infos[i][4]=='2':
            cnt2 += 1
        elif infos[i][3] > 0 and infos[i][4]=='3':
            cnt2 += 3

    if cnt1 < cnt2 and cnt2 < cnt3:
        print("3-bo'lim")
    elif cnt1 < cnt2 and cnt3 < cnt2:
        print("2-bo'lim")
    elif cnt2 < cnt1 and cnt3 < cnt1:
        print("1-bo'lim")
    elif cnt1 == cnt2 and cnt3 < cnt1:
        print("1-bo'lim")
        print("2-bo'lim")
    elif cnt2 == cnt3 and cnt1 < cnt2:
        print("2-bo'lim")
        print("3-bo'lim")
    elif cnt1 == cnt3 and cnt2 < cnt3:
        print("1-bo'lim")
        print("3-bo'lim")


all_data = Fill_Data()
print(all_data)
Check_Data(all_data)