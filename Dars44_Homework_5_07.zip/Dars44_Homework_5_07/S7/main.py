def fill_dict():
    data = {}
    while True:
        name = input("To'xtatish uchun 'c' ni bosing, Name: ")
        if name.capitalize() != 'C':
            num = int(input("1 yoki 0 kiriting: "))
            data[name] = num
        else:
            break

    return data

def Chech_data(info):
    cnt0, cnt1 = 0, 0
    for name, value in info.items():
        if value == 0:
            cnt0 += 1
        elif value == 1:
            cnt1 += 1
    
    if cnt1 > cnt0:
        print("1")
        for name, value in info.items():
            if value == 1:
                print(name, end = " ")
    elif cnt1 < cnt0:
        print("0")
        for name, value in info.items():
            if value == 0:
                print(name, end = " ")
    else:
        print("0")
        for name, value in info.items():
            if value == 0:
                print(name, end = " ")
        print('\n', "1")
        for name, value in info.items():
            if value == 1:
                print(name, end = " ")
data = fill_dict()
print(data)
Chech_data(data)
